(function() {
    'use strict';

    angular.module('agsMovApp.proveedores', [

    ]);
})();