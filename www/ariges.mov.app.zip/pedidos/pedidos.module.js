(function() {
    'use strict';

    angular.module('agsMovApp.pedidos', [

    ]);
})();