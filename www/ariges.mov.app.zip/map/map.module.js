(function() {
    'use strict';

    angular.module('agsMovApp.map', [

    ]);
})();