// Relacionado con la base de datos sclipot
var dbscliente = {
    codclien: null,
    nomclien: "",
    nomcomer: "",
    domclien: "",
    codpobla: "",
    pobclien: "",
    proclien: "",
    nifclien: "",
    wwwclien: "",
    fechamov: "",
    fechaalt: "",
    codactiv: "",
    perclie1: "",
    telclie1: "",
    faxclie1: "",
    maiclie1: "",
    perclie2: "",
    maiclie2: "",
    observac: ""
};