(function() {

    'use strict';

    angular.module('agsMovApp.core', [
        'blocks.router'
    ]);
})();
