(function() {
    'use strict';

    angular.module('agsMovApp.albaranes', [

    ]);
})();