(function() {
    'use strict';

    angular.module('agsMovApp.config', [

    ]);
})();